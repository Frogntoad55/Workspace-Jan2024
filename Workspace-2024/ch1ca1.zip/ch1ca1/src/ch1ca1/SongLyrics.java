//Taye Mansour 1/15/24 Lyrics
package ch1ca1;

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("She was more like a beauty queen from a movie scene");
		System.out.println("I said don't mind, but what do you mean, I am the one");
		System.out.println("Who will dance on the floor in the round?");
		System.out.println("She said I am the one, who will dance on the floor in the round");

	}

}
