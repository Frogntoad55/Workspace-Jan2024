//Taye M 1/15/24 Test
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from Taye");
		System.out.println("Hello from Taye");
		System.out.println("Hello from Taye");

	}

}
