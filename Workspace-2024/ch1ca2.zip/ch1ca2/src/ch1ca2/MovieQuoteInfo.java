//Taye Mansour 1/15/24 Quote
package ch1ca2;

public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Life is an endless series of trainwrecks with only brief commercial-like breaks of happiness.");
		System.out.println("Deadpool");
		System.out.println("2016");
		
	}

}
