//Taye Mansour 1/15/24 Triangle
package ch1a1;

public class Triangle {

	public static void main(String[] args) {
		System.out.println("hi");
		System.out.println("      X      ");
		System.out.println("     XXX     ");
		System.out.println("    XXXXX    ");
		System.out.println("   XXXXXXX   ");
		System.out.println("  XXXXXXXXX  ");
		System.out.println(" XXXXXXXXXXX ");
		System.out.println("XXXXXXXXXXXXX");
						
	}

}
